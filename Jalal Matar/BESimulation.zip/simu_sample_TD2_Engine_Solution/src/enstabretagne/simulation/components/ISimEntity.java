/*
 * 
 */
package enstabretagne.simulation.components;

/**
 * The Interface ISimEntity.
 */
public interface ISimEntity extends IEntity {

}
