package enstabretagne.simulation.core;

public interface IScenarioInstance {
	
	IScenario getScenarioInstance();

}
