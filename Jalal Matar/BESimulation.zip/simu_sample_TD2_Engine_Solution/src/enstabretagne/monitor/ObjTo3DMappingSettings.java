package enstabretagne.monitor;

public class ObjTo3DMappingSettings {
	public String classeObjetAMapper;
	public String Representation3DAMapper;
	public int level4Trasparency;
}
