/**
* Classe ListenerList.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.logger;

import java.util.ArrayList;

// TODO: Auto-generated Javadoc
/**
 * The Class ListenerList.
 *
 * @param <C> the generic type
 */
public class ListenerList<C> extends ArrayList<C> implements IListenerList<C>{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}

